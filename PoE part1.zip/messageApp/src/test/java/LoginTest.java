/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.messageapp.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author thoko
 */
class LoginTest {
    
     Login login = new Login();
     
     
      @Test
     void testPasswordCorrect(){
         assertTrue(login.checkPasswordComplexity("Ch&sec@ke99!"));
     }
     
      @Test
     void testPasswordIncorrect(){
         assertFalse(login.checkPasswordComplexity("password"));
     }
        
     @Test 
     void testUsernameCorrect(){
     assertTrue(login.checkUserName("kyl_1"));
     }
     
     @Test
     void testUsernameIncorrect(){
         assertFalse(login.checkUserName("kyle1111"));
     }
     
    
      @Test
     void testCellCorrect(){
         assertTrue(login.checkCellPhoneNumber("+27695654909"));
     }
     
     
      @Test
     void testCellIncorrect(){
         assertFalse(login.checkCellPhoneNumber("0695654909"));
     }
     
      @Test
     void testRegSuccess(){
         String expected = login.registerUser("kyl_1","Ch&sec@ke99!","kyle", "Smith", "+27695654909");
         assertTrue(expected.contains("Successfully captured"));
     }
     
      @Test
     void testLoginSuccess(){
         login.registerUser("kyl_1","Ch&sec@ke99!","kyle", "Smith", "+27695654909");
         assertTrue(login.loginUser("kyl_1", "Ch&sec@ke99!"));
     }
     
      @Test
     void testLoginFail(){
         assertFalse(login.loginUser("wrong", "pass"));
     }
     
     
    
        
    
    
    

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
