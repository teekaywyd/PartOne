/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messageapp;
import java.util.Scanner;
/**
 *
 * @author thoko
 */
public class MessageApp {

    public static void main(String[] args) {
        
        String username, password, firstName, cellPhone, regResult, lastName;
        boolean loggedIn;
        
        Scanner enter = new Scanner(System.in);
        Login login = new Login();
        
        System.out.println("***REGISTRATION***");
        
        System.out.print("Enter first name: ");
        firstName = enter.nextLine();
        
        System.out.print("Enter last name: ");
        lastName = enter.nextLine();
        
        
        System.out.print("Enter username(must contain '_' and <= 5 characters: ");
        username = enter.nextLine();
        
        System.out.print("Enter your password: ");
        password = enter.nextLine();       
       
        
        System.out.print("Enter cellPhone(+27XXXXXXXX): ");
        cellPhone = enter.nextLine();
        
        regResult = login.registerUser(password, username, cellPhone, firstName, lastName);
        System.out.print(regResult);
        
        if(regResult.contains("Successfully")){
            System.out.println("***LOGIN***");
            System.out.print("Enter username(must contain '_' and <= 5 characters: ");
            String loginUser = enter.nextLine();
            System.out.println("Enter password: ");
            String loginPass = enter.nextLine();
            
            loggedIn = login.loginUser(loginUser, loginPass);
            System.out.println(login.returnLoginStatus(loggedIn, firstName, lastName));
        }
        
       enter.close();
        
    }
}
